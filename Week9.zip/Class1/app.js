// this is a comment

/*
this is also a comment
*/

alert('JavaScript from a js file.');

// in the browser window, right click and inspect
console.log("logging to browser console");