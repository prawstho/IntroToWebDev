console.log('Hello World!');
console.log(2345);
console.log(false);

var message = 'In 2022 JavaScript was the most popular programming language!';
console.log(message);

console.log([3,4,5,6]);
console.log({a:1,b:2});
console.table({a:1,b:2});

console.error('this is an error.');
console.warn('this is a warning.');
